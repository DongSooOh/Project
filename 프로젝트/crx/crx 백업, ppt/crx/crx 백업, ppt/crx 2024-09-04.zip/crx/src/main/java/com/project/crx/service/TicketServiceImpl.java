package com.project.crx.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.project.crx.dao.TicketDAO;
import com.project.crx.vo.TicketVO;

@Service
public class TicketServiceImpl implements TicketService {

    private final TicketDAO ticketDAO;

    @Autowired
    public TicketServiceImpl(TicketDAO ticketDAO) {
        this.ticketDAO = ticketDAO;
    }
    @Override
    public List<TicketVO> getSeat(Map<String, Object> params) {

        return ticketDAO.getSeat(params);
    }
    @Override
    public void saveSeat(TicketVO seat) throws Exception {
        try {
            ticketDAO.insertSeat(seat);
        } catch (Exception e) {
            e.printStackTrace();
            throw new Exception("좌석 정보 저장에 실패했습니다.");
        }
    }
    
    @Override
    public List<TicketVO> getReservation(int userid) {
        return ticketDAO.getReservation(userid);
    }
    
    @Override
    public List<TicketVO> getPayment(int reservno) {
        return ticketDAO.getPayment(reservno);
    }
    
    @Override
    public List<TicketVO> getTicketing(int applyNum) {
    	System.out.println("applyNum: " + applyNum);
        return ticketDAO.getTicketing(applyNum);
    }
    
    @Override
    @Transactional //데이터 저장하면 안되니까 원복시키는 기능
    public boolean savePayment(TicketVO payment) {
        try {
            ticketDAO.insertPayment(payment);
            return true;
        } catch (Exception e) {
            // 로그를 기록합니다.
            System.err.println("Error saving payment: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }


}
