package com.project.crx;

public interface UserService {
	User findByUsermail(String usermail);

	void saveUser(User user);

	void updatePwdByMail(User user); // 비밀번호 업데이트 메소드 추가
}