package com.project.crx.vo;

import java.sql.Date;

import org.springframework.stereotype.Component;

@Component("CusVO")
public class CusVO {
	
	/* 고객안내 */
	
	/* 사용자 */
	private int userid;			// 사용자 ID
	private String userpwd;		// 사용자 PW
	private String username;	// 사용자 이름
	private int user_userid;	// 사용자 ID(FK)
	private String level;		// 사용자 등급
	
	/* 사원 */
	private int memid;			// 사원 ID
	private String mempwd;		// 사원 PW
	private String memname;		// 사원 이름
	private int member_memid;	// 사원 ID(FK)
	
	/* 게시판 공통 */
	private String type;		// 검색 타입
	private String keyword;		// 검색 키워드	
	
	/* 공지사항 */
	private int nono;			// 공지사항 - 번호
	private String notitle;		// 공지사항 - 제목
	private String nocontent;	// 공지사항 - 내용
	private Date nodate;		// 공지사항 - 작성일자
	private String filename;	// 공지사항 - 파일명
	private String filepath;	// 공지사항 - 파일경로
	private int nohit;			// 공지사항 - 조회수

	/* FAQ */
	private int faqno;			// FAQ - 번호
	private String faqtitle;	// FAQ - 제목
	private String faqcontent;	// FAQ - 내용
	private Date faqdate;		// FAQ - 작성일자
	private int faqhit;			// FAQ - 조회수
	
	/* 유실물 안내 */
	private int lostno;			// 유실물 안내 - 번호
	private String losttitle;	// 유실물 안내 - 제목
	private String lostcontent;	// 유실물 안내 - 내용
	private Date lostdate;		// 유실물 안내 - 접수일자
	private String lostplace;	// 유실물 안내 - 보관장소
	private int losthit;		// 유실물 안내 - 조회수
	
	/* Q&A(질문) */
	private int qno;			// Q&A(질문) - 번호
	private String qtitle;		// Q&A(질문) - 제목
	private String qcontent;	// Q&A(질문) - 내용
	private Date qdate;			// Q&A(질문) - 작성일자
	private String qstatus;		// Q&A(질문) - 답변상태
	private int qhit;			// Q&A(질문) - 조회수
	private int reply_count;	// Q&A(질문) - 답변 개수
	
	/* Q&A(답변) */
	private int rno;			// Q&A(답변) - 번호
	private String rcontent;	// Q&A(답변) - 내용
	private Date rdate;			// Q&A(답변) - 답변일자
	private int qna_qno;		// Q&A(답변) - 질문 번호(FK)
	
	public int getUserid() {
		return userid;
	}
		
	public void setUserid(int userid) {
		this.userid = userid;
	}
	
	public String getUserpwd() {
		return userpwd;
	}
	
	public void setUserpwd(String userpwd) {
		this.userpwd = userpwd;
	}
	
	public String getUsername() {
		return username;
	}
	
	public void setUsername(String username) {
		this.username = username;
	}
	
	public int getUser_userid() {
		return user_userid;
	}
	
	public void setUser_userid(int user_userid) {
		this.user_userid = user_userid;
	}
	
	public String getLevel() {
		return level;
	}
	
	public void setLevel(String level) {
		this.level = level;
	}
	
	public int getMemid() {
		return memid;
	}
	
	public void setMemid(int memid) {
		this.memid = memid;
	}
	
	public String getMempwd() {
		return mempwd;
	}
	
	public void setMempwd(String mempwd) {
		this.mempwd = mempwd;
	}
	
	public String getMemname() {
		return memname;
	}
	
	public void setMemname(String memname) {
		this.memname = memname;
	}
	
	public int getMember_memid() {
		return member_memid;
	}
	
	public void setMember_memid(int member_memid) {
		this.member_memid = member_memid;
	}
	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	
	public int getNono() {
		return nono;
	}
	
	public void setNono(int nono) {
		this.nono = nono;
	}
	
	public String getNotitle() {
		return notitle;
	}
	
	public void setNotitle(String notitle) {
		this.notitle = notitle;
	}
	
	public String getNocontent() {
		return nocontent;
	}
	
	public void setNocontent(String nocontent) {
		this.nocontent = nocontent;
	}
	
	public Date getNodate() {
		return nodate;
	}
	
	public void setNodate(Date nodate) {
		this.nodate = nodate;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public String getFilepath() {
		return filepath;
	}

	public void setFilepath(String filepath) {
		this.filepath = filepath;
	}

	public int getNohit() {
		return nohit;
	}
	
	public void setNohit(int nohit) {
		this.nohit = nohit;
	}
		
	public int getFaqno() {
		return faqno;
	}
	
	public void setFaqno(int faqno) {
		this.faqno = faqno;
	}
	
	public String getFaqtitle() {
		return faqtitle;
	}
	
	public void setFaqtitle(String faqtitle) {
		this.faqtitle = faqtitle;
	}
	
	public String getFaqcontent() {
		return faqcontent;
	}
	
	public void setFaqcontent(String faqcontent) {
		this.faqcontent = faqcontent;
	}
	
	public Date getFaqdate() {
		return faqdate;
	}
	
	public void setFaqdate(Date faqdate) {
		this.faqdate = faqdate;
	}
	
	public int getFaqhit() {
		return faqhit;
	}
	
	public void setFaqhit(int faqhit) {
		this.faqhit = faqhit;
	}
	
	public int getLostno() {
		return lostno;
	}
	
	public void setLostno(int lostno) {
		this.lostno = lostno;
	}
	
	public String getLosttitle() {
		return losttitle;
	}
	
	public void setLosttitle(String losttitle) {
		this.losttitle = losttitle;
	}
	
	public String getLostcontent() {
		return lostcontent;
	}
	
	public void setLostcontent(String lostcontent) {
		this.lostcontent = lostcontent;
	}
	
	public Date getLostdate() {
		return lostdate;
	}
	
	public void setLostdate(Date lostdate) {
		this.lostdate = lostdate;
	}
	
	public String getLostplace() {
		return lostplace;
	}
	
	public void setLostplace(String lostplace) {
		this.lostplace = lostplace;
	}
	
	public int getLosthit() {
		return losthit;
	}
	
	public void setLosthit(int losthit) {
		this.losthit = losthit;
	}
	
	public int getQno() {
		return qno;
	}
	
	public void setQno(int qno) {
		this.qno = qno;
	}
	
	public String getQtitle() {
		return qtitle;
	}
	
	public void setQtitle(String qtitle) {
		this.qtitle = qtitle;
	}
	
	public String getQcontent() {
		return qcontent;
	}
	
	public void setQcontent(String qcontent) {
		this.qcontent = qcontent;
	}
	
	public Date getQdate() {
		return qdate;
	}
	
	public void setQdate(Date qdate) {
		this.qdate = qdate;
	}
	
	public String getQstatus() {
		return qstatus;
	}
	
	public void setQstatus(String qstatus) {
		this.qstatus = qstatus;
	}
	
	public int getQhit() {
		return qhit;
	}
	
	public void setQhit(int qhit) {
		this.qhit = qhit;
	}
	
	public int getReply_count() {
		return reply_count;
	}

	public void setReply_count(int reply_count) {
		this.reply_count = reply_count;
	}

	public int getRno() {
		return rno;
	}
	
	public void setRno(int rno) {
		this.rno = rno;
	}
	
	public String getRcontent() {
		return rcontent;
	}

	public void setRcontent(String rcontent) {
		this.rcontent = rcontent;
	}

	public Date getRdate() {
		return rdate;
	}
	
	public void setRdate(Date rdate) {
		this.rdate = rdate;
	}
	
	public int getQna_qno() {
		return qna_qno;
	}
	
	public void setQna_qno(int qna_qno) {
		this.qna_qno = qna_qno;
	}	
}