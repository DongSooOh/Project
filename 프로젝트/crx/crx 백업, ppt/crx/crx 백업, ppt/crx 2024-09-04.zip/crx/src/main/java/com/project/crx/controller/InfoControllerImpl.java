package com.project.crx.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.project.crx.service.InfoService;

@Controller
public class InfoControllerImpl implements InfoController {
    
	@Autowired
    private InfoService infoService;
	
    /********** 종합이용안내 **********/
    
    // 열차서비스
    @GetMapping("/trainService.do")
    public String trainService() {
    	return "trainService";
    }
    
    // 연계교통서비스
    @GetMapping("/linkService.do")
    public String linkService() {
    	return "linkService";
    }
    
    // 휠체어서비스
    @GetMapping("/wheelService.do")
    public String wintheelService() {
    	return "wheelService";
    }
    
    /********** 승차권 이용안내 **********/
    
    // 승차권 구입/환불/분실
    @GetMapping("/ticketManagement.do")
    public String ticketManagement() {
    	return "ticketManagement";
    }
    
    // 열차지연/ 운행중지
    @GetMapping("/trainDelayStop.do")
    public String trainDelayStop() {
    	return "trainDelayStop";
    }
    
    // 열차운임 및 시간표
    @GetMapping("/trainFaresTime.do")
    public String trainFaresTime() {
    	return "trainFaresTime";
    }
    
    /********** 지연배상신청 **********/
    
    // 열차지연 시 교통비 지급 안내문
    @GetMapping("/trainDelayRefund.do")
    public String trainDelayRefund() {
    	return "trainDelayRefund";
    }
    
    // 지연료 계좌반환 신청
    @GetMapping("/delayRequest.do")
    public String delayRequest() {
    	return "delayRequest";
    }
    
    // 지연료 계좌반환 신청 - 승차권 인증
    @PostMapping("/ticketCheck.do")
    public ResponseEntity<Map<String, Integer>> checkTicket(@RequestParam("applyNum") String applyNum) throws Exception {
        // 데이터베이스에서 값을 가져오는 로직
        int refundAmount = infoService.getRefundAmount(applyNum);

        Map<String, Integer> response = new HashMap<>();
        response.put("refundAmount", refundAmount);

        return ResponseEntity.ok(response);
    }
    
    // 지연료 계좌반환 신청 - 작성 완료 후 확인 버튼 클릭 시 이동
    @PostMapping("/delayRequest.do")
    public String handleDelayRequest() {
        return "redirect:/delayRequest.do";
    }
    
    /********** 서비스 예약 **********/
    
    // 서비스 예약
    @GetMapping("/serviceReservation.do")
    public String serviceReservation() {
    	return "serviceReservation";
    }
}