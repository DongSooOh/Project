package com.project.crx;

import java.sql.SQLException;

import org.springframework.web.multipart.MultipartFile;

public interface PostService {
    void savePost(PostVO post) throws SQLException;
    String saveFile(MultipartFile file) throws Exception;
    void updatePost(PostVO post) throws SQLException;
}
