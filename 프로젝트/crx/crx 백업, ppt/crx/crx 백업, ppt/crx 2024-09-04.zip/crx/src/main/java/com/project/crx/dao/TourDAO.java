package com.project.crx.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.project.crx.vo.TourVO;

@Mapper
@Repository("TourDAO")
public interface TourDAO {
	//관광상품 리스트
	List<TourVO> tourList() throws DataAccessException;

	//관광상품 리스트에서 관광상품 삭제
	void tourDelete(String tournum);
    
	//관광상품 장바구니 추가
	void tourReserv(TourVO tourVO);
	
	//장바구니 페이지(관광상품)
	List<TourVO> cartList(String userid) throws Exception;
    
    //장바구니 페이지(기차예매)
	List<TourVO> trainList(String userid) throws Exception;
    
    //장바구니 관광상품 선택삭제
    void delTourCart(int reservno);

	//장바구니 기차예매 선택삭제
    void delTrainCart(int reservno);

	//관광상품 결제 DB저장
    void insertPaymentRecord(TourVO paymentRecord);    

	//발권관리 페이지(관광상품)
	List<TourVO> tourTicket(int apply_num) throws Exception;

	//결제완료시 장바구니 DB삭제(기차예매)
	void deltrainticket(int reservno) throws Exception;

	//결제완료시 장바구니 DB삭제(관광상품)
	void deltourticket(int reservno) throws Exception;

	//예매관리 페이지(기차예매)
	List<TourVO> mgmtTrain(int userid) throws Exception;

	//예매관리 페이지(관광상품)
	List<TourVO> mgmtTour(int userid) throws Exception;
    
	//환불페이지(기차예매)
	List<TourVO> refundTrain(int apply_num) throws Exception;

	//환불페이지(관광상품)
	List<TourVO> refundTour(int apply_num) throws Exception;

	//환불성공 DB업데이트(기차예매)
	void refundUpTour(int apply_num) throws Exception;

	//환불성공 DB업데이트(관광상품)
	void refundUpTrain(int apply_num) throws Exception;

	//이용내역 페이지(기차예매)
	List<TourVO> usageTrain(int userid) throws Exception;
    
	//이용내역 페이지(관광상품)
	List<TourVO> usageTour(int userid) throws Exception;

	//이용내역 페이지 기간검색(기차예매)
    List<TourVO> trainSearch(@Param("userid") int userid, 
            @Param("startDate") java.util.Date startDate, 
            @Param("endDate") java.util.Date endDate) throws Exception;

	//이용내역 페이지 기간검색(관광상품)
    List<TourVO> tourSearch(@Param("userid") int userid, 
            @Param("startDate") java.util.Date startDate, 
            @Param("endDate") java.util.Date endDate) throws Exception;
}
