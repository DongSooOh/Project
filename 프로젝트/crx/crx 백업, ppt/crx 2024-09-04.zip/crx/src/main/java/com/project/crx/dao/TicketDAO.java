package com.project.crx.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.project.crx.vo.TicketVO;

@Mapper
public interface TicketDAO {
	List<TicketVO> getSeat(Map<String, Object> params);	
    void insertSeat(TicketVO seat) throws Exception;
	List<TicketVO> getReservation(int userid);
	List<TicketVO> getPayment(int reservno);
	void insertPayment(TicketVO payment);
	List<TicketVO> getTicketing(int applyNum);	
}

