package com.project.crx.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.project.crx.service.TicketService;
import com.project.crx.vo.TicketVO;

@Controller
public class TicketControllerImpl implements TicketController {
	
    private final TicketService ticketService;
	private Object ticketingService;

    // 생성자 주입
    public TicketControllerImpl(TicketService ticketService) {
        this.ticketService = ticketService;
    }
	
	//일반예매
    @GetMapping("/ticket.do")
    public String ticket() {
        return "ticket"; 
    }
    
    //단체예매
    @GetMapping("/groupTicket.do")
    public String groupTicket() {
        return "groupTicket"; 
    }
    
    //역 명 조회 작은 팝업
    @GetMapping("/mapKTXstart.do")
	public String mapKTXstart() {
	    return "mapKTXstart"; 
	}
    @GetMapping("/mapKTXend.do")
	public String mapKTXend() {
	    return "mapKTXend"; 
	}
	@GetMapping("/mapSRTstart.do")
	public String mapSRTstart() {
	    return "mapSRTstart"; 
	}
	@GetMapping("/mapSRTend.do")
	public String mapSRTend() {
	    return "mapSRTend"; 
	}
	@GetMapping("/mapCRXstart.do")
	public String mapCRXstart() {
	    return "mapCRXstart"; 
	}
	@GetMapping("/mapCRXend.do")
	public String mapCRXend() {
	    return "mapCRXend"; 
	}
	//좌석예매 팝업
	@GetMapping("/seat.do")
	public String seat(Model model, @RequestParam("trainno") String trainno, 
			@RequestParam("startdate") String startdate,
			@RequestParam("depTime") String depTime,
			@RequestParam("arrTime") String arrTime) {
	    Map<String, Object> params = new HashMap<>();
	    System.out.println("sssssss");
	    System.out.println(depTime);
	    params.put("trainno", trainno);
	    params.put("startdate", startdate);
	    params.put("depTime", depTime);
	    params.put("arrTime", arrTime);
	    
	    List<TicketVO> seat = ticketService.getSeat(params);
	    System.out.println("dddd");
	    System.out.println(startdate);
	    System.out.println(depTime);
	    System.out.println(arrTime);
	    if (seat == null || seat.isEmpty()) {
	        System.out.println("No ticketing data available.");
	    }
	    model.addAttribute("seat", seat);
	    return "seat"; // JSP 페이지 이름
	}

	@PostMapping("/seat.do")
	public ModelAndView saveSeat(@ModelAttribute("seat") TicketVO seat, BindingResult result, RedirectAttributes rAttr) {
		System.out.println("fss");
		System.out.println(seat);
	    ModelAndView mav = new ModelAndView("redirect:/seat.do?trainno=" + seat.getTrainno() + "&" + "startdate=" + seat.getStartdate()
	    + "&" + "depTime=" + seat.getDepTime()+ "&" + "arrTime=" + seat.getArrTime());

	    if (result.hasErrors()) {
	        mav.addObject("message", "좌석 정보 저장에 실패했습니다. 입력값을 확인해 주세요.");
	        mav.setViewName("seat");
	        return mav;
	    }

	    try {
	        // 좌석 정보를 저장하는 서비스 호출
	        ticketService.saveSeat(seat);
	        rAttr.addFlashAttribute("message", "좌석 정보가 성공적으로 저장되었습니다.");
	    } catch (Exception e) {
	        e.printStackTrace();
	        rAttr.addFlashAttribute("message", "좌석 정보 저장에 실패했습니다.");
	    }
	   
	    return mav;
	}


    //예약
    @GetMapping("/reservation.do")
    public String reservation(Model model, @RequestParam("userid") int userid) {
        // 서비스 레이어를 통해 예약 정보 가져오기
        List<TicketVO> reservation = ticketService.getReservation(userid);
        
        // 모델에 예약 정보 추가
        model.addAttribute("reservation", reservation);

        return "reservation"; // JSP 페이지 이름
    }

    
    //결제
    @GetMapping("/payment.do")
    public String payment(Model model, @RequestParam("reservno") int reservno) {
    	System.out.println("111111111111");
    	
    	List<TicketVO> payment = ticketService.getPayment(reservno);
        
        // 모델에 예약 정보 추가
        model.addAttribute("payment", payment);

        return "payment"; // JSP 페이지 이름
    }
    @PostMapping("/payment.do")
    public ModelAndView savePayment(@ModelAttribute("payment") TicketVO payment, BindingResult result, RedirectAttributes rAttr) {
        ModelAndView mav = new ModelAndView();
        System.out.println("dffsdsd");
        System.out.println(payment.getReservno());
        if (result.hasErrors()) {
            // 유효성 검사 실패 시 에러 메시지를 모델에 추가하고 폼으로 돌아감
            mav.addObject("message", "좌석 정보 저장에 실패했습니다. 입력값을 확인해 주세요.");
            mav.setViewName("payment");
            return mav;
        }

        try {
            // 좌석 정보를 저장하는 서비스 호출
            rAttr.addFlashAttribute("message", "예매 정보가 성공적으로 저장되었습니다.");
            mav.setViewName("redirect:/payment.do?reservno=" + payment.getReservno()); // 성공 후 리디렉션할 페이지
        } catch (Exception e) {
            e.printStackTrace();
            rAttr.addFlashAttribute("message", "예매 정보 저장에 실패했습니다.");
            mav.setViewName("payment"); // 실패 시 다시 폼 페이지로 돌아가기
        }

        return mav;
    }
    @PostMapping("/ticketPay")
    @ResponseBody
    public String handlePaymentResult(@RequestBody TicketVO paymentRecord) {
        // 데이터베이스에 저장
        boolean success = ticketService.savePayment(paymentRecord);
        return success ? "Success" : "Error";
    }
    

    
    //발권
    @GetMapping("/ticketing.do")
    public String ticketing(Model model, @RequestParam("apply_num") int applyNum) {
        List<TicketVO> ticketing = ticketService.getTicketing(applyNum);
        if (ticketing == null || ticketing.isEmpty()) {
            System.out.println("No ticketing data available.");
        }
        model.addAttribute("ticketing", ticketing);
        return "ticketing"; // JSP 페이지 이름
    }

    
    //예매관리
    @GetMapping("/management.do")
    public String management() {
        return "management"; 
    }
    
    //이용내역
    @GetMapping("/usageDetails.do")
    public String usageDetails() {
        return "usageDetails"; 
    }
    
    //환불
    @GetMapping("/refund.do")
    public String refund() {
        return "refund"; 
    }
    
    //화천역
    @GetMapping("/stationHwacheon.do")
    public String stationHwacheon() {
        return "stationHwacheon"; 
    }
    //양구역
    @GetMapping("/stationYanggu.do")
    public String stationYanggu() {
        return "stationYanggu"; 
    }
    //인제역
    @GetMapping("/stationInje.do")
    public String stationInje() {
        return "stationInje"; 
    }
    //고성역
    @GetMapping("/stationGoseong.do")
    public String stationGoseong() {
        return "stationGoseong"; 
    }
    //속초역
    @GetMapping("/stationSokcho.do")
    public String stationSokcho() {
        return "stationSokcho"; 
    }
    //양양역
    @GetMapping("/stationYangyang.do")
    public String stationYangyang() {
        return "stationYangyang"; 
    }

	public ModelAndView saveSeat(TicketVO seat, RedirectAttributes rAttr) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ModelAndView savePayment(TicketVO payment, RedirectAttributes rAttr) {
		// TODO Auto-generated method stub
		return null;
	}


	
}