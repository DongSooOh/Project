package com.project.crx.controller;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public interface TourController {
	
	ModelAndView tourList(HttpServletRequest request, HttpServletResponse response) throws Exception;

	ModelAndView tourDelete(String tourDelete, HttpServletRequest request, HttpServletResponse response) throws Exception;

	ModelAndView tourReserv(HttpServletRequest request, HttpServletResponse response, RedirectAttributes rAttr)	throws Exception;		
	
}