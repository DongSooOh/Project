package com.project.crx;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class PostServiceImpl implements PostService {

    @Autowired
    private PostRepository postRepository;

    @Override
    public void savePost(PostVO post) throws SQLException {
        postRepository.save(post);
    }

    @Override
    public String saveFile(MultipartFile file) throws Exception {
        String uploadDir = "uploads/"; // 업로드할 디렉토리
        Path path = Paths.get(uploadDir + file.getOriginalFilename());
        Files.copy(file.getInputStream(), path);
        return path.toString();
    }
    
    @Override
    public void updatePost(PostVO post) throws SQLException {
        postRepository.save(post); // save() 메서드는 존재하는 엔티티를 업데이트함
    }
}