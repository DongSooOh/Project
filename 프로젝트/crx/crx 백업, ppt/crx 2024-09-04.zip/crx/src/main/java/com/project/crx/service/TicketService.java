package com.project.crx.service;

import java.util.List;
import java.util.Map;

import com.project.crx.vo.TicketVO;

public interface TicketService {
	List<TicketVO> getSeat(Map<String, Object> params);
    void saveSeat(TicketVO seat) throws Exception;
    List<TicketVO> getReservation(int userid);
	List<TicketVO> getPayment(int reservno);
	boolean savePayment(TicketVO payment);
	List<TicketVO> getTicketing(int applyNum);
}
