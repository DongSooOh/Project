package com.project.crx.service;

public interface InfoService {

	// 승차권 조회
	Integer getRefundAmount(String applyNum) throws Exception;
}
