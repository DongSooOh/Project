package com.project.crx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrxApplicationTests {

	@Test
	void contextLoads() {
	}

}
